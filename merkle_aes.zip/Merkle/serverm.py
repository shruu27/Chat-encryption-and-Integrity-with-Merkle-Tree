import socket

def start_server():

    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_address = ('localhost', 12345)  
    server_socket.bind(server_address)


    server_socket.listen(1)
    print("Server is listening for incoming connections...")

    client_socket, client_address = server_socket.accept()
    print(f"Accepted connection from {client_address}")


    received_data = client_socket.recv(1024)

    with open("received_file_encrypted.txt", "wb") as file:
        file.write(received_data)

    print("Encrypted file received successfully!")

    client_socket.sendall(received_data)
    print("Encrypted file sent back to the client!")

    client_socket.close()
    server_socket.close()

if __name__ == "__main__":
    start_server()
