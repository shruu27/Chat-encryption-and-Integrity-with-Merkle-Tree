import socket
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
from Crypto.Random import get_random_bytes
import hashlib

def encrypt_file(file_path, key):
    # Read the file content
    with open(file_path, "rb") as file:
        file_data = file.read()

    # Generate an initialization vector (IV)
    iv = get_random_bytes(16)

    # Create an AES cipher object with CBC mode
    cipher = AES.new(key, AES.MODE_CBC, iv)

    # Encrypt the file data
    encrypted_data = cipher.encrypt(pad(file_data, AES.block_size))

    # Return the IV and encrypted data
    return iv + encrypted_data

def decrypt_file(encrypted_data, key, iv):
    # Create an AES cipher object with CBC mode
    cipher = AES.new(key, AES.MODE_CBC, iv)

    # Decrypt the file data
    decrypted_data = unpad(cipher.decrypt(encrypted_data[AES.block_size:]), AES.block_size)

    return decrypted_data

def merkle_tree_hash(leaves):
    if len(leaves) == 1:
        return leaves[0]

    new_leaves = []
    for i in range(0, len(leaves)-1, 2):
        combined = leaves[i] + leaves[i+1]
        new_leaves.append(hashlib.sha256(combined).digest())

    if len(leaves) % 2 != 0:
        new_leaves.append(leaves[-1])

    return merkle_tree_hash(new_leaves)

def start_client():
    # Set up the client socket
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_address = ('localhost', 12345)  

    client_socket.connect(server_address)
    print("Connected to the server")

    key = get_random_bytes(32)

    encrypted_file_data = encrypt_file("testtxt.txt", key)

    initial_root_hash = merkle_tree_hash([hashlib.sha256(chunk).digest() for chunk in [encrypted_file_data[i:i+32] for i in range(0, len(encrypted_file_data), 32)]])
    print("Initial Merkle Tree Root Hash:", initial_root_hash.hex())

    client_socket.sendall(encrypted_file_data)
    print("Encrypted file sent successfully!")

    received_encrypted_data = client_socket.recv(1024)

    received_root_hash = merkle_tree_hash([hashlib.sha256(chunk).digest() for chunk in [received_encrypted_data[i:i+32] for i in range(0, len(received_encrypted_data), 32)]])
    print("Received Merkle Tree Root Hash:", received_root_hash.hex())

    if initial_root_hash == received_root_hash:
        print("Merkle Tree Root Hashes match. File integrity is maintained.")
        
        # Decrypt the received file data
        decrypted_data = decrypt_file(received_encrypted_data, key, encrypted_file_data[:AES.block_size])
        
        # Write the decrypted data to a file
        with open("decrypted_file.txt", "wb") as file:
            file.write(decrypted_data)
        
        print("File decrypted and saved as 'decrypted_file.txt'")
    else:
        print("Merkle Tree Root Hashes do not match. File integrity may be compromised.")
    client_socket.close()

if __name__ == "__main__":
    start_client()
